#include <stdio.h>
#include <stdlib.h>

/*
 * Tests whether the given parameter is a valid int or not
 *
 * Parameters:
 *   num - int indicating which parameter the string is (1-3)
 *   command - string from the command-line arguments that is being tested as a valid int
 *
 * Returns:
 *   0 if command has a valid int (an actual integer value that is a power of two (and is not less than four if num is 3)), 1 if not
 */
int is_valid_int(int num, char *command);

/*
 * Tests whether the string is a valid input or not
 *
 * Parameters:
 *   num - int indicating which command-line argument the string is (4-6)
 *   command - the string containing the command-line argument
 *
 * Returns:
 *   0 if command is a valid argument (equal to one of the given commands), 1 if not
 */
int is_valid_input(int num, char *command);

/*
 * Converts a string that prints an int to an int variable
 *
 * Parameters:
 *   command - the string being converted to an int
 *
 * Returns:
 *   the int that the string was converted to
 */
int string_to_int(char *command);

/*
 * Discerns which command-line argument is being used
 *
 * Parameters:
 *   num - int indicating which command-line argument the string is (4-6)
 *   command - string containint the command-line argument
 *
 * Returns:
 *   0 for the first possible argument option, 1 for the second
 */
int which_command(int num, char *command);

/*
 * Brings the relavent memory block into the cache before proceeding
 *
 * Parameters:
 *
 * Returns:
 *   0
 */
int write_allocate();

/*
 * Writes to the cache and memory
 *
 * Parameters:
 *
 * Returns:
 *   0
 */
int write_through();

/*
 * Writes to the cache only and marks the block as dirty
 *
 * Parameters:
 *
 * Returns:
 *   0
 */
int write_back();

/*
 * Does least-recently-used eviction
 *
 * Parameters:
 *
 * Returns:
 *   0
 */
int lru();

/*
 * Does first-in-first-out eviction
 *
 * Parameters:
 *
 * Returns:
 *   0
 */
int fifo();

/*
 * Runs the actual cache testing
 *
 * Parameters:
 *   sets - number of sets in the cache
 *   blocks - number of blocks in each set
 *   bytes - number of bytes in each block
 *   is_write_allocate - whether relavent memory should be brought on a miss or not (0 if yes, 1 if no)
 *   is_write_through - whether the command-line argument was write-through (0) or write-back (1)
 *   is_rlu - whether blocks should be evicted via rlu (0) or fefo (1)
 *
 * Returns:
 *   0
 */
int cache_test(int sets, int blocks, int bytes, int is_write_allocate, int is_write_through, int is_rlu);

/*
 * Main function
 *
 * Parameters:
 *   argc - the number of strings without spaces there are in argv
 *   argv - string of command-line arguments
 *
 * Returns:
 *   0 if there were no errors, 1 is there was at least one error
 */
int main(int argc, char **argv);
