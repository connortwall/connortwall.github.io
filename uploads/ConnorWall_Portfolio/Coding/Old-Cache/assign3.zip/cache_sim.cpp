#include <stdio.h>
#include <stdlib.h>
#include "cache_sim.h"

int is_valid_int(int num, char *command){
  //check if it's actually an int
  for(int i = 0; command[i] != '\0'; i++) {
    if (command[i] < '0' || command[i] > '9') {
      //char is not an int
      //insert error call here. Error message: not an int
      return 1;
    }
  }

  //convert to int (setting equal to 0 as a placeholder)
  int val = 0;
  
  //check if int is a power of 2

  //if num == 3, check if int < 4 (return 1 if so)
  if (num == 3) {
    if (val < 4) {
      return 1;
    }
  }
  
  return 0;
}

int is_valid_input(int num, char *command){
  command[0] = num;
  
  return 0;
}

int string_to_int(char *command) {
  //temporarily here to get rid of "unused variable" warning
  command[0] = 0;
  
  return 0;
}

int which_command (int num, char *command) {
  //temporarily here to get rid of "unused variable" warning
  command[0] = num;
  
  return 0;
}

int write_allocate() {
  return 0;
}

int write_through() {
  return 0;
}

int write_back() {
  return 0;
}

int lru() {
  return 0;
}

int fifo() {
  return 0;
}

int cache_test(int sets, int blocks, int bytes, int is_write_allocate, int is_write_through, int is_rlu) {
  //temporary stuff to eliminate unused-variable warnings
  int temp = sets + blocks + bytes + is_write_allocate + is_write_through + is_rlu;
  printf("%i\n", temp);
  
  return 0;
}

int main(int argc, char **argv) {
  //break the check-for-error loop if it's anything but 0
  int has_error = 0;

  //start string array iterator at 1 because argv[0] is the command calling the program
  int i = 1;

  //variables for command-line arguments
  int sets;
  int blocks;
  int bytes;
  
  //0 == yes, 1 == no
  int is_write_allocate;
  int is_write_through;
  int is_rlu;
  
  //loop to check if command-line arguments are valid. Iterate through strings in argv while has_error is zero
  while(has_error == 0 && i < argc) {
    //is_int for first three arguments
    if(i < 4) {
      has_error = is_valid_int(i, argv[i]); 
    }
    else {
      has_error = is_valid_input(i, argv[i]);
    }
    
    i++;
  }

  //check if has_error is 1
  if (has_error == 1) {
    return 1;
  }

  //send to function to turn string of int into int
  sets = string_to_int(argv[1]);
  blocks = string_to_int(argv[2]);
  bytes = string_to_int(argv[3]);

  //send command-line arguments 4-6 to which_command to see which one is being used
  is_write_allocate = which_command(4, argv[4]);
  is_write_through = which_command(5, argv[5]);
  is_rlu = which_command(6, argv[6]);

  //function to test if all of the commands make sense (like not having no-write with write-back)

  //function that actually runs tests
  cache_test(sets, blocks, bytes, is_write_allocate, is_write_through, is_rlu);
  
  return 0;
}
