# assignment03

Madison Rostan
Connor Wall

Everything in milestone 1 was written by Maddie.

Specific notes on the code, proper:
 - stdio.h is only included for temporary print statements to remove compilation warnings caused by having unused variables. It will be removed before the next submission.
 - the error tests and string_to_int/which_command will probably be further integrated so that the error tests (if not returned prematurely) return a value that can double as the argument-related int and has_error. This will also make main more condensed
