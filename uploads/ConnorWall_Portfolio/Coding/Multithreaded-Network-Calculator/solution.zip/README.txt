Maddie Rostan
Connor Wall

Maddie and Connor worked together on each calc.cpp and calcServer.c. Originally starting with by character parsing into a char,int map, we switched to a string,int map to make use of tokenize and more easily capture parameters. We used an adaptation of the server in server.c sample code from class to complete the calcServer, simplifying the while loop return conditions and adjusting them to use the "chat_with_client" function from calcInteractive.c

Assignment 6 update:
Maddie and Connor worked together to implement threads and mutexes. Clean server shutdown was initially implemented but was later removed due to causing issues with passing the concurrency stress test.
