#include "calc.h"
#include <stdlib.h>
#include <string>
#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
#include <sstream>

//general calulator exception
class calculator_exception : public std::runtime_error {
  public:
  calculator_exception(const std::string& msg) : std::runtime_error(msg) {
  }

};

//exception for invalid input
class invalid_input : public calculator_exception {
  public:
  invalid_input(const std::string& msg) : calculator_exception(msg) {
  }
};

//exception for invalid var
class invalid_var : public calculator_exception {
  public:
  invalid_var(const std::string& msg) : calculator_exception(msg) {
  }
};

//exception for invalid operand
class invalid_operand : public calculator_exception {
  public:
  invalid_operand(const std::string& msg) : calculator_exception(msg) {
  }
};

//exception for invalid operator
class invalid_operator : public calculator_exception {
  public:
  invalid_operator(const std::string& msg) : calculator_exception(msg) {
  }
};

//exception for undefined var
class undefined_var : public calculator_exception {
  public:
  undefined_var(const std::string& msg) : calculator_exception(msg) {
  }
};

//exception for division by zero
class div_by_zero : public calculator_exception {
  public:
  div_by_zero(const std::string& msg) : calculator_exception(msg) {
  }
};


struct Calc {
public:
  //public member functions
  Calc() {
  } 

  ~Calc() {
  }

  std::map<std::string, int> vars;

  //main evaluate function
  int evalExpr(const std::string &expr, int &result) {
    std::vector<std::string> vec = tokenize(expr);
    try {
      if((vec.size() == 3 || vec.size() == 5) && vec[1] == "=") {
        result = handle_assignment(vec);
      } else {
        result = handle_statement(vec);
        }
        //expected return val
        return 1;
      } catch (const calculator_exception& e) {
          //specific error printing
          //std::cerr << "error: " << e.what() << std::endl;
        //error found
        return 0;
      }
  }
  //two cases with "var ="
  int handle_assignment(std::vector<std::string> vec) {
    int length = vec.size();
    std::string var = vec[0];
    if (length == 3 || length == 5) {
      if(!is_var(var)) {
        throw invalid_var(var);
      }
      if(length == 3) {
      vars[var] = to_int(vec[2]);
      }
      else if(length == 5) {
      vars[var] = operate(vec[2],vec[3],vec[4]);
      }
      return vars[var];
    }
    else {
      throw invalid_input("inpavild input: '" + vec[0] + "'");
    }
  } 

  // two cases without "var ="
  int handle_statement(std::vector<std::string> vec) {
    int length = vec.size();
    if(length == 1) {
      return to_int(vec[0]);     
    }
    if(length == 3) {
      return operate(vec[0], vec[1], vec[2]);
    }
    else {
      throw invalid_input("inpavild input: '" + vec[0] + "'");
    } 
  }

  //math of operation of left, operation, and right string
  int operate(std::string left, std::string op, std::string right) {
    int lhs = to_int(left);
    int rhs = to_int(right);
    
    if(op.length() == 1) {
      switch(op[0]) {
      case '+': return lhs + rhs;
      case '-': return lhs - rhs;
      case '*': return lhs * rhs;
      case '/': 
        if (rhs == 0) {
        throw div_by_zero("div by 0");
      }
      return lhs / rhs;
      default:
      break;
      }
    }
    throw invalid_operator("invailid operator: '" + op + "'");
  }

  //convert string operand to int
  int to_int(const std::string& operand) {
    if(is_int(operand)) {
      return stoi(operand);
    }

    if(is_var(operand)) {
      auto var = vars.find(operand);
      if(var == vars.end()) {
        throw undefined_var("undefined var: '" + std::to_string (var->second) + "'");
      }
      return var->second;
    }

    throw invalid_operand("invalid operand: '" + operand + "'" );
  }

  //check if string is valid int
  bool is_int(const std::string& operand) {
    if(operand[0] != '-' && (operand[0] < '0' || operand[0] > '9')) {
      return false;
    }
    
    for(int i = 1; i < (int) operand.size(); i++) {
      if(operand[i] < '0' || operand[i] > '9') {
        return false;
      }
    }
    return true;
  }

  //check if string is valid var
  bool is_var(const std::string& operand) {
    for(int i = 0; i < (int) operand.size(); i++) {
      if((operand[i] >= 'A' && operand[i] <= 'Z') || (operand[i] >= 'a' && operand[i] <= 'z')) {
        return true;
      }
    }
    return false;
  }

private:
//use the following function to break an input expression into tokens
  std::vector<std::string> tokenize(const std::string &expr) {
    std::vector<std::string> vec;
    std::stringstream s(expr);
    std::string tok;
    while (s >> tok) {
      vec.push_back(tok);
    }
    return vec;
  }
};  


extern "C" struct Calc *calc_create(void) {
    return new Calc();
}

extern "C" void calc_destroy(struct Calc *calc) {
    delete calc;
}

extern "C" int calc_eval(struct Calc *calc, const char *expr, int *presult) {
  //error handling
  try {
    int status = calc->evalExpr(expr, *presult);   
    //std::cout << *presult << std::endl;
    //returns 1 if good, 0 if error
    return status;
    } catch(const calculator_exception& e) {
      std::cout << "error:" << e.what() << std::endl;
  }
  //return in instance of error
  return -1;
}


//alternate draft
/*
std::map<char, int> vars;

int identify_char(char i) {
  //is operand
  if ((i == '+') || (i == '-') || (i == '*') || (i == '/')) {
    return 0;
  }
  //is =
  else if (i == '=') {
    return 1;
  }
  //is number
  else if (i >= 48 && i <= 57) {
    return 3;
  }
  //else it's a variable
  return 2;
}

int get_int(const std::string &expr, int start) {  
  int num = 0;
  //iterate through string until a null terminator or space is reached
  for(int i = start; expr[i] != '\n' && expr[i] != '0'; i++) {
    //the numerical value is equal to the character value - 48
    num += (expr[i] - 48);
    //if the next character isn't a space or null terminator, then it's another number. multiply by 10
    if(expr[i + 1] != '\n' && expr[i + 1] != ' ') {
      num *= 10;
    }
  }
  return num;
}

int calculate(int var1, int var2, char operand) {
  //calculate base on operand
  switch(operand) {
  case '+': return var1 + var2;
  case '-': return var1 - var2;
  case '*': return var1 * var2;
  case '/': return var1 / var2;
  }

  //extra return statement to prevent compilation warnings
  return 0;
}

bool set_equals_check(const std::string &expr) {
  //error check (make sure string has [var] = [var or number] format)
  if(identify_char(expr[0]) != 2 || expr[1] != ' ' || expr[2] != '=' || expr[3] != ' ' || (identify_char(expr[4]) != 2 && identify_char(expr[4]) != 3)) {
    return true;
  }

  return false;
}

int var_equals(const std::string &expr, char key) {
  int type = identify_char(expr[4]);
  if(type == 2) {
    vars[key] = vars[expr[4]];
  }
  else {
    vars[key] = get_int(expr, 4);
  }
  //printf("%i\n", vars[key]);
  return vars[key];
}

bool is_operation(const std::string &expr, int start) {
  for(int i = start; expr[i] != '\n' && expr[i] != '0'; i++) {
    printf("%i\n", identify_char(expr[i]) == 3);
    printf("%i\n", identify_char(expr[i - 1]) == 2);
    if((identify_char(expr[i]) == 2 && identify_char(expr[i - 1]) == 3) || (identify_char(expr[i]) == 3 && identify_char(expr[i - 1]) == 2)) {
      printf("hit55\n");
      return false;
    }
    else if(identify_char(expr[i]) == 0 && (identify_char(expr[i - 1]) != ' ' || identify_char(expr[i + 1]) != ' ')) {
      printf("hit56\n");
      return false;
    }
  }
  return true;
}

int operation(const std::string &expr, int start) {
  int var1;
  int var2;
  char op;


  //get first operand
  if(identify_char(expr[start]) == 2) {
    var1 = vars[expr[start]];
    start++;
  }
  else {
    var1 = get_int(expr, start);
    start = expr.find(' ', start);
  }

  //get op
  op = expr[start + 1];
  start += 2;

  //get second operand
  if(identify_char(expr[start]) == 2) {
    var2 = vars[expr[start]];
  }
  else {
    var2 = get_int(expr, start);
  }

  return calculate(var1, var2, op);
}

int get_functions(const std::string &expr, int &result) {
  //one operand
  if (expr.length() == 2) {
    if(identify_char(expr[0]) == 2) {
      result = vars[expr[0]];
      return 1;
    }
    else if(identify_char(expr[0]) == 3) {
      result = get_int(expr, 0);
      return 1;
    }
    printf("Error\n");
    return 0;
  }

  //only a number
  if (std::count(expr.begin(), expr.end(), ' ') == 0){
    for(int i = 0; i < (int)expr.length(); i++) {
      if(identify_char(expr[i]) != 3) {
	printf("hit2\n");
	printf("Error\n");
	return 0;
      }
    }
    //actually is just a number
    result = get_int(expr, 0);
    return 1;
  }


  //var =
  else if(!set_equals_check(expr)) {
    //var = operand
    if(std::count(expr.begin(), expr.end(), ' ') == 2) {
      if(identify_char(expr[4]) == 2) {
	vars[expr[0]] = vars[expr[4]];
      }
      else if(identify_char(expr[4]) == 3) {
	vars[expr[0]] = get_int(expr, 5);
      }
      result = vars[expr[0]];
      return 1;
    }
  
    //var = operand op operand
    else if(std::count(expr.begin(), expr.end(), ' ') == 4 && is_operation(expr, 4)) {
      printf("hit5\n");
      vars[expr[0]] = operation(expr, 5);
      result = vars[expr[0]];
      return 1;
    }
    printf("hit6\n");
    printf("Error\n");
    return 0;
  }

  //operand op operand
  else if (is_operation(expr, 0)) {
    result = operation(expr, 0);
    return 1;
  }

  printf("hit7\n");
  printf("Error\n");
  return 0;
  
}

int evalExpr(const std::string &expr, int &result) {
  int outcome = get_functions(expr, result);
  if(outcome == 1) {
    printf("%i\n", result);
  }
  
  return outcome;
}*/