Madison Rostan
Connor Wall

Connor, unfortunately, came down with a cold and could not work on the project as much as he otherwise would have. He was able to go to office hours to get necessary feedback for the project and add a list of suggested functions to textsearch_fns.h, some of which were implemented. Maddie wrote and tested the code for milestone 1.

For milestone 3, Madison wrote assembly code for phrases and counter. Connor edited makefile, added tests to read_line and instances. He wrote assmebly code for read_line, error, instances, and counter. He corrected c file code functions: instances, counter, read_line.
