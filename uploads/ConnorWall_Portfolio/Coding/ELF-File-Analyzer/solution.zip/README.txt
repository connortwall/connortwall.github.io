Assignment 4
Maddie Rostan
Connor Wall

Maddie and Connor co-coded on multiple days. Connor wrote the for loops, the checks to see if the file is actually an elf file, and locating the section & symbol header tables. Maddie coded the print statements, error calls, and locating the section header names and symbol header named.  
